# hlf cluster on multiple hosts

Read more infomarions from [here](https://medium.com/coinmonks/hyperledger-fabric-cluster-on-multiple-hosts-af093f00436)
