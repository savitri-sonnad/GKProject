Maintainers
-----------

+---------------------------+---------------------+------------------+----------------+-------------------------------------+
| Name                      | Gerrit              | GitHub           | RocketChat     | email                               |
+===========================+=====================+==================+================+=====================================+
| Bret Harrison             | bretharrison        | harrisob         | bretharrison   | beharrison@nc.rr.com                |
+---------------------------+---------------------+------------------+----------------+-------------------------------------+
| Chaoyi Zhao               | zhaochy             | zhaochy1990      | zhaochy        | zhaochy_2015@hotmail.com            |
+---------------------------+---------------------+------------------+----------------+-------------------------------------+
| Chris Ferris              | ChristopherFerris   | christo4ferris   | cbf            | chris.ferris@gmail.com              |
+---------------------------+---------------------+------------------+----------------+-------------------------------------+
| Gari Signh                | mastersingh24       | mastersingh24    | garisingh      | gari.r.singh@gmail.com              |
+---------------------------+---------------------+------------------+----------------+-------------------------------------+
| Andrew Coleman            | andrew-coleman      | andrew-coleman   | andrew-coleman | andrew_coleman@uk.ibm.com           |
+---------------------------+---------------------+------------------+----------------+-------------------------------------+
| Jonathan Levi             | JonathanLevi        | hacera           | JonathanLevi   | jonathan@hacera.com                 |
+---------------------------+---------------------+------------------+----------------+-------------------------------------+
| Keith Smith               | smithbk             | smithbk          | smithbk        | bksmith@us.ibm.com                  |
+---------------------------+---------------------+------------------+----------------+-------------------------------------+

Also: Please see the Release Manager section here
  https://github.com/hyperledger/fabric/blob/master/docs/source/MAINTAINERS.rst

Licensed under Creative Commons Attribution 4.0 International License
  https://creativecommons.org/licenses/by/4.0/
