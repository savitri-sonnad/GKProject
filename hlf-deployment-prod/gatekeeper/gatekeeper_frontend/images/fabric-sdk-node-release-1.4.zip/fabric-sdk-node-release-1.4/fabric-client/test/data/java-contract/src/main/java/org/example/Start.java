/**
 * Copyright 2018 IBM All Rights Reserved.
 *
 * SPDX-License-Identifier: Apache-2.0
 */

package org.example;

public class Start {

    public static void main(String[] args) {
        new Chaincode().start(args);
    }

}
