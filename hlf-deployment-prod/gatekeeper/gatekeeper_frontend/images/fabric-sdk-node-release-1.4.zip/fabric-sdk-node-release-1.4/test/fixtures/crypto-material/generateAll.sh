#
# SPDX-License-Identifier: Apache-2.0
#

# One generate file to rule them all

cd ./config-base
./generate.sh
cd ../config-update
./generate.sh


